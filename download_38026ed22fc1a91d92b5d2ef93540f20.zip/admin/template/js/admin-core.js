function adminTopMenu(id)
{
	alert(id);
}