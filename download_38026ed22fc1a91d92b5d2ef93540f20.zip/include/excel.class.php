<?php
class Excel
{
	public statics function createXls($arr=array())
	{
		
	}
}

?>