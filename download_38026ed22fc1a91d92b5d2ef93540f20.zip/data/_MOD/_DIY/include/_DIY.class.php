<?php

// +----------------------------------------------------------------------

// | phpWeChat #_DIY# 操作类 Last modified #nowtime#

// +----------------------------------------------------------------------

// | Copyright (c) 2009-2016 phpWeChat http://www.phpwechat.com All rights reserved.

// +----------------------------------------------------------------------

// | Author: 骑马的少年 <phpwechat@126.com> <http://www.phpwechat.com>

// +----------------------------------------------------------------------

namespace _MOD_PARENT\_DIY_CLASS;

use phpWeChat\Area;

use phpWeChat\CaChe;

use phpWeChat\Config;

use phpWeChat\DataInput;

use phpWeChat\DataList;

use phpWeChat\Member;

use phpWeChat\Module;

use phpWeChat\MySql;

use phpWeChat\Order;

use phpWeChat\Upload;



class _DIY_CLASS

{

	public static $mPageString=''; // 这个静态成员是系统自带，请勿删除
	public static $mTotalPage=0; // 这个静态成员是系统自带，请勿删除

	



}

?>