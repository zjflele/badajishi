<?php
use _MOD_PARENT\_DIY_CLASS\_DIY_CLASS;
use phpWeChat\Area;
use phpWeChat\CaChe;
use phpWeChat\Config;
use phpWeChat\Member;
use phpWeChat\Module;
use phpWeChat\MySql;
use phpWeChat\Order;
use phpWeChat\Upload;

//此处写该模块用到的一些操作函数
//function test()
//{
//	echo 'hello world!';
//}
?>