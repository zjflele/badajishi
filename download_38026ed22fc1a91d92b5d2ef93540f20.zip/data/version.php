<?php

	define('PHPWECHAT_VERSION','1.1');

	define('PHPWECHAT_RELEASE','.6');

?>